<?php
/**
 * Settings screen (Settings → Malipo), written for shop owners.
 *
 * @package Malipo
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers the option, the settings page, its fields and the connection test.
 */
class Malipo_Settings {

	const OPTION = 'malipo_settings';

	/**
	 * Hook into WordPress.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_post_malipo_test', array( __CLASS__, 'handle_test' ) );
	}

	/**
	 * Default option values.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'api_base'       => 'https://api.kiosk.ke',
			'secret_key'     => '',
			'webhook_secret' => '',
		);
	}

	/**
	 * All settings, merged over the defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$saved = get_option( self::OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return wp_parse_args( $saved, self::defaults() );
	}

	/**
	 * Read one setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback.
	 * @return mixed
	 */
	public static function get( $key, $default = '' ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : $default;
	}

	/**
	 * Add the options page.
	 */
	public static function menu() {
		add_options_page(
			__( 'Malipo', 'malipo-payments' ),
			__( 'Malipo', 'malipo-payments' ),
			'manage_options',
			'malipo',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register the option and its fields.
	 */
	public static function register() {
		register_setting(
			'malipo',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);

		add_settings_section(
			'malipo_keys',
			__( 'Connect your shop', 'malipo-payments' ),
			array( __CLASS__, 'section_keys' ),
			'malipo'
		);

		add_settings_field( 'malipo_secret_key', __( 'Payment key', 'malipo-payments' ), array( __CLASS__, 'field_secret_key' ), 'malipo', 'malipo_keys' );
		add_settings_field( 'malipo_webhook_secret', __( 'Signing code', 'malipo-payments' ), array( __CLASS__, 'field_webhook_secret' ), 'malipo', 'malipo_keys' );
		add_settings_field( 'malipo_api_base', __( 'API address', 'malipo-payments' ), array( __CLASS__, 'field_api_base' ), 'malipo', 'malipo_keys' );
	}

	/**
	 * Sanitise the option array.
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$out = self::defaults();
		if ( ! is_array( $input ) ) {
			return $out;
		}

		if ( isset( $input['api_base'] ) ) {
			$base            = esc_url_raw( trim( (string) $input['api_base'] ) );
			$out['api_base'] = '' !== $base ? $base : $out['api_base'];
		}
		if ( isset( $input['secret_key'] ) ) {
			$out['secret_key'] = sanitize_text_field( trim( (string) $input['secret_key'] ) );
		}
		if ( isset( $input['webhook_secret'] ) ) {
			$out['webhook_secret'] = sanitize_text_field( trim( (string) $input['webhook_secret'] ) );
		}

		return $out;
	}

	/**
	 * Section intro copy.
	 */
	public static function section_keys() {
		echo '<p>' . esc_html__( 'Open Malipo Connect, copy the two codes it shows you, and paste them here. You only do this once.', 'malipo-payments' ) . '</p>';
	}

	/**
	 * Payment key field.
	 */
	public static function field_secret_key() {
		printf(
			'<input type="password" class="regular-text" autocomplete="off" name="%1$s[secret_key]" value="%2$s" placeholder="sk_live_…" />',
			esc_attr( self::OPTION ),
			esc_attr( self::get( 'secret_key', '' ) )
		);
		echo '<p class="description">' . esc_html__( 'Starts with sk_live_. This is your payment key.', 'malipo-payments' ) . '</p>';
	}

	/**
	 * Signing code field.
	 */
	public static function field_webhook_secret() {
		printf(
			'<input type="password" class="regular-text" autocomplete="off" name="%1$s[webhook_secret]" value="%2$s" placeholder="whsec_…" />',
			esc_attr( self::OPTION ),
			esc_attr( self::get( 'webhook_secret', '' ) )
		);
		echo '<p class="description">' . esc_html__( 'Starts with whsec_. This keeps payment confirmations secure.', 'malipo-payments' ) . '</p>';
	}

	/**
	 * API address field.
	 */
	public static function field_api_base() {
		printf(
			'<input type="url" class="regular-text" name="%1$s[api_base]" value="%2$s" placeholder="https://api.kiosk.ke" />',
			esc_attr( self::OPTION ),
			esc_attr( self::get( 'api_base', 'https://api.kiosk.ke' ) )
		);
		echo '<p class="description">' . esc_html__( 'Leave this as it is unless we tell you otherwise.', 'malipo-payments' ) . '</p>';
	}

	/**
	 * Render the settings page.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$webhook = rest_url( 'malipo/v1/webhook' );
		$result  = isset( $_GET['malipo_test'] ) ? sanitize_key( wp_unslash( $_GET['malipo_test'] ) ) : '';
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Malipo — M-Pesa payments', 'malipo-payments' ); ?></h1>
			<p>
				<?php esc_html_e( 'Take M-Pesa on your WordPress shop. Confirm where money lands in Malipo Connect, then paste the two codes it shows you here.', 'malipo-payments' ); ?>
			</p>

			<?php self::render_notice( $result ); ?>

			<form action="options.php" method="post">
				<?php
				settings_fields( 'malipo' );
				do_settings_sections( 'malipo' );
				submit_button( __( 'Save changes', 'malipo-payments' ) );
				?>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:0.5rem">
				<input type="hidden" name="action" value="malipo_test" />
				<?php wp_nonce_field( 'malipo_test' ); ?>
				<?php submit_button( __( 'Test connection', 'malipo-payments' ), 'secondary', 'submit', false ); ?>
				<p class="description"><?php esc_html_e( 'Sends a quick check to Malipo to confirm your payment key works.', 'malipo-payments' ); ?></p>
			</form>

			<hr />

			<h2><?php esc_html_e( 'Callback address', 'malipo-payments' ); ?></h2>
			<p>
				<?php esc_html_e( 'Already set up for you. This is where Malipo reports each payment, and the plugin checks it before trusting it.', 'malipo-payments' ); ?>
			</p>
			<p><code><?php echo esc_html( $webhook ); ?></code></p>

			<p>
				<?php esc_html_e( 'Not sure where to find these? See the', 'malipo-payments' ); ?>
				<a href="https://kiosk.ke/wordpress" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'setup guide', 'malipo-payments' ); ?></a>.
			</p>
		</div>
		<?php
	}

	/**
	 * Print the result of the last connection test.
	 *
	 * @param string $result Result flag.
	 */
	private static function render_notice( $result ) {
		if ( '' === $result ) {
			return;
		}

		$map = array(
			'ok'          => array( 'notice-success', __( 'Connection works — your payment key was accepted.', 'malipo-payments' ) ),
			'bad'         => array( 'notice-error', __( 'That payment key was not accepted. Copy it again from Malipo Connect.', 'malipo-payments' ) ),
			'missing'     => array( 'notice-warning', __( 'Add your payment key first, then test again.', 'malipo-payments' ) ),
			'unreachable' => array( 'notice-error', __( 'Could not reach Malipo. Check your settlement setup and try again.', 'malipo-payments' ) ),
		);

		if ( ! isset( $map[ $result ] ) ) {
			return;
		}

		printf(
			'<div class="notice %1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $map[ $result ][0] ),
			esc_html( $map[ $result ][1] )
		);
	}

	/**
	 * Handle the "Test connection" button.
	 */
	public static function handle_test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'malipo-payments' ) );
		}
		check_admin_referer( 'malipo_test' );

		$result = Malipo_API::from_settings()->test_connection();

		if ( true === $result ) {
			$flag = 'ok';
		} elseif ( is_wp_error( $result ) ) {
			$code = $result->get_error_code();
			if ( 'malipo_not_configured' === $code ) {
				$flag = 'missing';
			} elseif ( 'malipo_unauthorized' === $code ) {
				$flag = 'bad';
			} else {
				$flag = 'unreachable';
			}
		} else {
			$flag = 'unreachable';
		}

		wp_safe_redirect(
			add_query_arg(
				'malipo_test',
				$flag,
				admin_url( 'options-general.php?page=malipo' )
			)
		);
		exit;
	}
}
