# Malipo — M-Pesa Payments (WordPress plugin)

Accept M-Pesa payments on WordPress through [Malipo](../../docs/INTEGRATION.md).
One key, one request, no Daraja app. Ships a **WooCommerce gateway** and a
standalone **`[malipo_pay]`** shortcode, both built on the same client and webhook.

## What it does

- Prompts the customer's phone with an M-Pesa STK push (`POST /v1/payments`).
- Verifies every callback with HMAC-SHA256 over the raw body
  (`X-Malipo-Signature: sha256=…`) using your `whsec_…` secret.
- Never trusts the callback body on its own — it confirms with
  `GET /v1/payments/{id}` and marks the order paid **only** when that returns
  `settled`. The M-Pesa receipt is stored on the order/record.
- Falls back to polling on the order-received page, so it works even if the
  webhook never arrives.
- Uses one idempotency key per attempt, so a retried request never double-charges.

## Install

Copy this folder into `wp-content/plugins/`, or zip it and upload it via
**Plugins → Add New → Upload Plugin**, then activate **Malipo — M-Pesa Payments**.

There is no build step. Requires WordPress 6.0+, PHP 7.4+. WooCommerce is optional.

## Configure

Go to **Settings → Malipo** and paste what Malipo Connect shows you:

| Field | Example | Notes |
|---|---|---|
| API base URL | `https://api.kiosk.ke` | The base URL from the request Connect copied. |
| Secret key | `sk_live_…` | Sent as `Authorization: Bearer …`. Shown once. |
| Webhook signing secret | `whsec_…` | Verifies callback signatures. |

The page also shows your **Callback URL** — paste it into Malipo Connect if your
account asks for one. The plugin sends it as `callback_url` on every payment.

## WooCommerce

1. **WooCommerce → Settings → Payments → M-Pesa (Malipo)** → enable.
2. Checkout collects the customer's M-Pesa phone, creates the payment, and puts
   the order **on hold**.
3. When the payment settles, the order is completed (receipt stored as the
   transaction id); when it fails, the order is marked failed.

The gateway only appears when a secret key is set and the store currency is KES.

## Shortcode

Charge any amount from a page, post, or block:

```
[malipo_pay amount="100" reference="donation-42" button="Pay KES 100"]
```

Attributes: `amount` (required), `reference`, `title`, `button`. The form collects
a phone number, creates the payment, and polls until it settles or fails.

Each payment is recorded as a **Malipo Payment** under the **Malipo** admin menu.

## How it fits together

```
malipo-payments.php        plugin bootstrap
includes/
  class-malipo-util.php       phone normalisation + formatting
  class-malipo-api.php        POST /v1/payments, GET /v1/payments/{id}
  class-malipo-settings.php   Settings → Malipo
  class-malipo-payments.php   payment records (CPT) + create/refresh
  class-malipo-rest.php       /pay, /status/{token}, /webhook
  class-malipo-shortcode.php  [malipo_pay] rendering
  class-malipo-gateway.php    WooCommerce gateway (loaded only if WooCommerce)
assets/
  css/malipo.css
  js/malipo-pay.js
```

REST routes (`/wp-json/malipo/v1/…`):

| Route | Purpose |
|---|---|
| `POST /pay` | Create a payment from the shortcode (nonce-protected). |
| `GET /status/{token}` | Poll a payment by its unguessable token. |
| `POST /webhook` | Malipo callback; signature-verified, then confirmed via GET. |

## Security notes

- Callbacks are rejected with `401` unless the signature matches your
  `webhook_secret`. A missing secret yields `500` rather than trusting the body.
- Status polling uses a random 32-hex token, not a guessable id.
- The API secret key is stored in the WordPress options table; restrict
  `manage_options` as usual.

## Trying it

With Malipo running locally (see `../../service`), set the API base URL to
`http://127.0.0.1:4000`, paste the `sk_live_…` from Connect, and send a KES 1 test
from the shortcode or checkout. Local `http://localhost` callback URLs are
accepted by Malipo, so the webhook path is testable too.
